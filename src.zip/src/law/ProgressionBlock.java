package law;
class ProgressionBlock {
	DrawableText[] textQueue;
	public ProgressionBlock () {
		
	}
}